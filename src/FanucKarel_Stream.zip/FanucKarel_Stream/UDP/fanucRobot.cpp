#include "fanucRobot.h"
#include <algorithm>

struct sockaddr_in robotAddr, myAddr;

namespace fanucRobot
{
    fanucRobot::fanucRobot(std::string ip)
    {
        this->ipAddr = ip;
        sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (sockfd < 0)
        {

            std::cout << "sockNum :" << sockfd << std::endl;
        }
        else
        {
            std::cout << "sock initialization starting...." << std::endl;
            std::cout << "sockNum :" << sockfd << std::endl;
        }
    }
    bool fanucRobot::estabalishedComm(std::string robotIP)
    {
        bool comStatus = false;

        std::cout << "Sock Numver: " << sockfd << std::endl;

        // memset((char *)&robotAddr, 0,sizeof(robotAddr));
        robotAddr.sin_family = AF_INET;
        robotAddr.sin_addr.s_addr = inet_addr(robotIP.c_str()); // need to look deeper into this.
        robotAddr.sin_port = htons(port);
        std::cout << "Connection has started.... " << std::endl;
        connect(sockfd, (struct sockaddr *)&robotAddr, sizeof(robotAddr));
    }

    void fanucRobot::sendStartData()
    {

        std::cout << "Size of struct: " << sizeof(startStatus) << std::endl;
        int n = write(sockfd, (const char *)(&startStatus), sizeof(startStatus));
        //int val = sendto(sockfd,(const char *)(&startStatus),sizeof(startStatus),0,NULL,0);
        if (n < 0)
        {
            std::cout << "error sending data to server, val: " << n << std::endl;
        }
        else
        {
            std::cout << "msg has been set" << std::endl;
            startSeqID = ntohl(roboStatusPac.sequenceNumRobot);
            std::cout << "Val: " << startSeqID << std::endl;
        }
    }

    void fanucRobot::recieveStatusData(int num)
    {
        // not using num just for overloading purposes

        socklen_t addrLen = sizeof(robotAddr);
        std::cout << "about to recv" << std::endl;

        int recvlenStruct;
        std::cout << "waiting for this port " << this->port << std::endl;

        //recvlen = recvfrom(this->sockfd, (char *)&recvData, sizeof(recvData), MSG_WAITALL, (struct sockaddr*)&robotAddr, &addrLen);
        recvlenStruct = read(sockfd, (char *)&roboStatusPac, sizeof(roboStatusPac));
        if ((roboStatusPac.statusRobot & 1) > 0)
        {
            for (int index = 0; index < 6; index++)
            {
                u_long joint = ntohl(roboStatusPac.jointAngle[index]);
                curJoint[index] = reinterpret_cast<float &>(joint);

                std::cout << "Joint " << index << ": " << curJoint[index];
            }
            startSeqID = ntohl(roboStatusPac.sequenceNumRobot);
        }
        else
        {
            std::cout << "not stuck : " << startSeqID << std::endl;
        }
    }

    void fanucRobot::sendMotionCommands(std::string fname)
    {
        // from a csv file we will end -
    }

    void fanucRobot::printStatus()
    {
        std::string n;
        std::cout << "Status packetType(RAW): " << roboStatusPac.packetTypeRobot << std::endl;
        std::cout << "Status packetType(ntohl): " << ntohl(roboStatusPac.packetTypeRobot) << std::endl
                  << std::endl;

        std::cout << "Status versionNum(RAW): " << roboStatusPac.versionNumRobot << std::endl;
        std::cout << "Status versionNum(ntohl): " << ntohl(roboStatusPac.versionNumRobot) << std::endl
                  << std::endl;

        std::cout << "Status sequenceNum(RAW): " << roboStatusPac.sequenceNumRobot << std::endl;
        std::cout << "Status sequenceNum(ntohl): " << ntohl(roboStatusPac.sequenceNumRobot) << std::endl
                  << std::endl;

        std::cout << "Status status(RAW): " << roboStatusPac.statusRobot << std::endl;
        std::cout << "Status status(&): " << (roboStatusPac.statusRobot & 1) << std::endl;

        std::cout << "Status readIOType(RAW): " << roboStatusPac.readIOTypeRobot << std::endl;
        std::cout << "Status readIOType(&): " << (roboStatusPac.readIOTypeRobot & 1) << std::endl;

        std::cout << "Status ReadIOIndex(RAW): " << roboStatusPac.readIOIndexRobot << std::endl;
        std::cout << "Status ReadIOIndex(ntohs): " << ntohs(roboStatusPac.readIOIndexRobot) << std::endl
                  << std::endl;

        std::cout << "Status readIOVal(RAW): " << roboStatusPac.readIOValueRobot << std::endl;
        std::cout << "Status readIoVal(ntohs): " << ntohs(roboStatusPac.readIOValueRobot) << std::endl
                  << std::endl;

        std::cout << "Status readIOMask(RAW): " << roboStatusPac.readIOMaskRobot << std::endl;
        std::cout << "Status readIoMask(ntohs): " << ntohs(roboStatusPac.readIOMaskRobot) << std::endl
                  << std::endl;

        std::cout << "Status timeStamp(RAW): " << roboStatusPac.timeStampRobot << std::endl;
        std::cout << "Status timeStamp(ntohl): " << ntohl(roboStatusPac.timeStampRobot) << std::endl
                  << std::endl;

        for (int index = 0; index < 6; index++)
        {
            uint32_t tempPos = htonl(roboStatusPac.position[index]);
            //std::cout << "Status position" << index+1 <<" (RAW): " << roboStatusPac.position[index] <<std::endl;
            //std::cout << "Status position" << index+1 <<" (htohl): " << tempPos <<std::endl;
            initPositions();
            curPos[index] = reinterpret_cast<float &>(tempPos);
            std::cout << "Status Pos" << index + 1 << " (casted): " << curPos[index] << std::endl;
        }

        for (int index = 0; index < 6; index++)
        {
            uint32_t tempJoint = htonl(roboStatusPac.jointAngle[index]);
            //std::cout << "Status joint" << index+1 <<" (RAW): " << roboStatusPac.jointAngle[index] <<std::endl;
            //std::cout << "Status joint" << index+1 <<" (htohl): " << tempJoint <<std::endl;
            initJoints();
            this->curJoint[index] = reinterpret_cast<float &>(tempJoint);
            std::cout << "Status joint" << index + 1 << " (casted): " << curJoint[index] << std::endl;
        }

        for (int index = 0; index < 6; index++)
        {
            uint32_t tempCurr = htonl(roboStatusPac.current[index]);
            //std::cout << "Status current" << index+1 <<" (RAW): " << roboStatusPac.current[index] <<std::endl;
            //std::cout << "Status current" << index+1 <<" (htohl): " << htonl(roboStatusPac.current[index]) <<std::endl;
            initCurrents();
            curCurr[index] = reinterpret_cast<float &>(tempCurr);
            std::cout << "Status current" << index + 1 << " (casted): " << curCurr[index] << std::endl;
        }
    }

    void fanucRobot::initJoints()
    {
        for (int i = 0; i < 9; i++)
        {
            curJoint[i] = 0.0f;
        }
    }
    void fanucRobot::initPositions()
    {
        for (int i = 0; i < 9; i++)
        {
            curPos[i] = 0.0f;
        }
    }
    void fanucRobot::initCurrents()
    {
        for (int i = 0; i < 9; i++)
        {
            curCurr[i] = 0.0f;
        }
    }

    void fanucRobot::createTrajectoryCSV(std::ofstream &myfile, std::vector<float> j1, std::vector<float> j2, float steps, std::string fname)
    {

        // std::vector<float> last_WP = j1; // J1 = last waypoint bc this is a continuation from rampCSV positon
        // std::vector<float> new_WP, tempWP;
        // new_WP.clear();
        // tempWP.clear();
        // float wpVal;
        // float delta = -0.02; // the delta that 
        // int count = 0;

        // std::string tempS;
        // std::cout << "Joint 4 num: " << std::to_string(last_WP[3]).c_str() << std::endl;
        // std::cout << "Joint 5 num: " << last_WP[4] << std::endl;

        // // eveything this is a test rn.. so only joint four is being modified. 
        // // in the near future i will chnage accordinhgly.
        // // j2 is not being used bc it will be used later

        // if (myfile.is_open())
        // {
        //     for (int i = 1; i <= steps; i++)
        //     {
        //         for (int j = 1; j <= 6; j++)
        //         {
        //             if (j == 6)
        //             {
        //                 std::cout << "J" << j << ": " << 0 << "\n" << std::endl;
        //                 myfile << 0 << "\n";
        //                 wpVal = 0;
        //                 new_WP.push_back(wpVal);
        //                 count++;
        //                 std::cout << "c: " << count << std::endl;
                        
        //                 checkJointVel(last_WP, new_WP);
        //                 tempWP = new_WP;
        //                 new_WP.clear();
        //                 last_WP.clear();
        //                 last_WP = tempWP;
        //                 tempWP.clear();

        //             }
        //             else if (j == 4)
        //             {

        //                 wpVal = last_WP[j - 1] + delta;
        //                 new_WP.push_back(wpVal);

        //                 //std::cout << "about to print Joint " << curJoint[j-1] << std::endl;
        //                 std::cout << "J" << j << ": " << std::to_string(last_WP[j - 1]).c_str() << " ";
        //                 myfile << std::to_string(last_WP[j - 1]).c_str() << ",";
        //             }
        //             else
        //             {
        //                 //wpVal =  last_WP[j-1]  + delta;
        //                 wpVal = 0;
        //                 new_WP.push_back(wpVal);

        //                 // std::cout <<"J" <<j <<": " << std::to_string(last_WP[j-1]).c_str() << " ";
        //                 //myfile << std::to_string(last_WP[j-1]).c_str() << "\t";

        //                 std::cout << "J" << j << ": " << 0 << " ";
        //                 myfile << 0 << ",";

        //             }

                // if(i < rampUpPer)
                // {
                //     if(j==6)
                //     {

                //     std::cout << "J" <<j <<": " << std::to_string(tempJoint[j-1]).c_str() << "\n" <<std::endl;
                //     myfile << std::to_string(tempJoint[j-1]).c_str() << "\n";
                //     count++;
                //     std::cout << "c: " <<count <<std::endl;

                //     }
                //     else if(j == 1)
                //     {

                //         tempJoint[j-1] =  tempJoint[j-1]  + 0.001;
                //         std::cout <<"J" <<j <<": " << std::to_string(tempJoint[j-1]).c_str() << " ";
                //         myfile << std::to_string(tempJoint[j-1]).c_str() << "\t";

                //     }
                //     else
                //     {
                //         std::cout <<"J" <<j <<": " << std::to_string(tempJoint[j-1]).c_str() << " ";
                //         myfile << std::to_string(tempJoint[j-1]).c_str() << "\t";
                //     }

                // }
                // else if( i > rampUpPer)
                // {
                //     if(j==6)
                //     {

                //     std::cout << "J" <<j <<": " << std::to_string(tempJoint[j-1]).c_str() << "\n" <<std::endl;
                //     myfile << std::to_string(tempJoint[j-1]).c_str() << "\n";
                //     count++;
                //     std::cout << "c: " <<count <<std::endl;

                //     }
                //     else if(j == 1)
                //     {

                //         tempJoint[j-1] =  tempJoint[j-1]  + 0.001;
                //         std::cout <<"J" <<j <<": " << std::to_string(tempJoint[j-1]).c_str() << " ";
                //         myfile << std::to_string(tempJoint[j-1]).c_str() << "\t";

                //     }
                //     else
                //     {
                //         std::cout <<"J" <<j <<": " << std::to_string(tempJoint[j-1]).c_str() << " ";
                //         myfile << std::to_string(tempJoint[j-1]).c_str() << "\t";
                //     }
                // }
        
        std::vector<float> tempJ;
        tempJ.clear();
        for(int i = 0; i < minAxis; i++)
        {
            
        }
        tempJ.push_back(curJoint[i])
        
            if(j==6)
            {
            std::cout << "J" <<j <<": " << std::to_string(tempJoint[j-1]).c_str() << "\n" <<std::endl;
            myfile << std::to_string(tempJoint[j-1]).c_str() << "\n";
            count++;
            std::cout << "c: " <<count <<std::endl;

            }
            else if(j == 1)
            {

                tempJoint[j-1] =  tempJoint[j-1]  + 0.001;
                std::cout <<"J" <<j <<": " << std::to_string(tempJoint[j-1]).c_str() << " ";
                myfile << std::to_string(tempJoint[j-1]).c_str() << "\t";

            }
            else
            {
                std::cout <<"J" <<j <<": " << std::to_string(tempJoint[j-1]).c_str() << " ";
                myfile << std::to_string(tempJoint[j-1]).c_str() << "\t";
            }
            
        
        }
        else
        {
            std::cout << "Didnt Open" << std::endl;
        }

        j1.clear();
        j1.push_back(last_WP[0]);
        j1.push_back(last_WP[1]);
        j1.push_back(last_WP[2]);
        j1.push_back(last_WP[3]);
        j1.push_back(last_WP[4]);
        j1.push_back(last_WP[5]);
    }
    float fanucRobot::avgDelta(std::ifstream &myfile)
    {
    }
    void fanucRobot::rampCSV(std::ofstream &myfile, std::vector<float> &j1)
    {
        float tempJoint[6];
        std::string tempS;
        float delta = -0.001;
        int steps = 100;
        int count = 0;

        tempJoint[0] = 0; //curJoint[0];
        tempJoint[1] = 0;//curJoint[1];
        tempJoint[2] = 0; //curJoint[2];
        tempJoint[3] = 0; //curJoint[3];
        tempJoint[4] = 0; //curJoint[4];
        tempJoint[5] = 0; //curJoint[5];

        if (myfile.is_open())
        {
            for (int i = 1; i <= steps; i++)
            {

                for (int j = 1; j <= 6; j++)
                {
                    if (j == 6)
                    {

                        std::cout << "J" << j << ": " << std::to_string(tempJoint[j - 1]).c_str() << "\n"
                                  << std::endl;
                        myfile << std::to_string(tempJoint[j - 1]).c_str() << "\n";
                        count++;
                        std::cout << "c: " << count << std::endl;
                    }
                    else if (j == 4)
                    {

                        tempJoint[j - 1] = tempJoint[j - 1] + delta;

                        std::cout << "J" << j << ": " << std::to_string(tempJoint[j - 1]).c_str() << " ";
                        myfile << std::to_string(tempJoint[j - 1]).c_str() << ",";
                    }
                    else
                    {
                        std::cout << "J" << j << ": " << std::to_string(tempJoint[j - 1]).c_str() << " ";
                        myfile << std::to_string(tempJoint[j - 1]).c_str() << ",";
                    }
                }
            }
        }

        j1.push_back(tempJoint[0]);
        j1.push_back(tempJoint[1]);
        j1.push_back(tempJoint[2]);
        j1.push_back(tempJoint[3]);
        j1.push_back(tempJoint[4]);
        j1.push_back(tempJoint[5]);
    }
    void fanucRobot::checkJointVel(std::vector<float> j1, std::vector<float> j2)
    {
        int jVelLim[] = {210, 210, 265, 420, 420, 720};
        std::vector<float> jVel;
        float tempVal, maxJVal, sampleRate = 0.008;

        for (int i = 0; i < 6; i++)
        {
            tempVal = (j2[i] - j1[i]) * (1/ sampleRate);
            tempVal = fabs(tempVal);
            jVel.push_back(tempVal);
        }
        maxJVal = *max_element(jVel.begin(), jVel.end());

        for(int i = 0; i < minAxis; i++) //This is for debugging purposes
        {
            if (maxJVal >= jVelLim[i])
            {
                std::cout << "size of J1 " << j1.size() <<std::endl;
                std::cout << "size of J2 " << j2.size() <<std::endl;

                for(int c = 0; c < minAxis; c++)
                {
                    std::cout << "Joint 1 Values [" << i+1 << "]: " << j1[i] <<std::endl;
                    std::cout << "Joint 2 Values [" << i+1 << "]: " << j2[i] <<std::endl;

                }
                std::cout << "Joint Limit Error Axis " << i+1  <<std::endl;
                std::cout << "Joint Velcoity value: " << maxJVal  << " Max Joint Velocity value"  << jVelLim[i] << std::endl;
                break;
            }
            else
            {
                continue;
            }
        }
        
    }

    void fanucRobot::readCSV(std::ifstream &inFile)
    {
        int dataCount;
        int lineDataCount;
        int lineCount = 0; // line count
        std::string inLine;
        std::vector<float> lineJoints;
        std::vector<float> tempCurJoint;

        tempCurJoint.push_back(curJoint[0]);
        tempCurJoint.push_back(curJoint[1]);
        tempCurJoint.push_back(curJoint[2]);
        tempCurJoint.push_back(curJoint[3]);
        tempCurJoint.push_back(curJoint[4]);
        tempCurJoint.push_back(curJoint[5]);

        if (!inFile)
        {
            std::cout << "Unable to open file: " << std::endl;
        }
        else
        { // File exists
            std::cout << "reading file: " << std::endl;
            while (!inFile.eof())
            {
                getline(inFile, inLine);
                if (lineCount == 0)
                {
                    lineJoints = parseString(inLine, ",");

                    std::cout << "these are line joints size: " <<lineJoints.size()  << "jointVal: " <<lineJoints[0] <<std::endl;
            
                    checkJointVel(tempCurJoint, lineJoints);

                    lineDataCount = lineJoints.size();
                    std::cout << "data size: " << lineDataCount << std::endl;
                    if (lineDataCount == 0)
                    {
                        lineJoints = parseString(inLine, " ");
                        lineDataCount = lineJoints.size();
                        std::cout << "data size use space: " << lineDataCount << std::endl;
                    }

                    if ((lineDataCount != 9) && (lineDataCount != 6))
                    {
                        std::cout << "Invalid data count" << std::endl;
                    }
                    lineCount++;
                    tempCurJoint.clear();
                    tempCurJoint = lineJoints;
                }
                else
                {

                    lineJoints = parseString(inLine, ",");
                    checkJointVel(tempCurJoint, lineJoints);

                    dataCount = lineJoints.size();
                    if (dataCount == lineDataCount)
                    {
                        lineCount++;
                    }
                    tempCurJoint.clear();
                    tempCurJoint = lineJoints;
                }

                // istringstream ss(inLine);
                // copy(istream_iterator <float>(ss), istream_iterator <float>(), back_inserter(angles));
                //for (size_t idx = 0; idx < angles.size(); idx++) {
                //cout << angles[idx] << " , ";
                //}
                //cout << "\n";

            } // end while
        }
    }

    std::vector<float> fanucRobot::parseString(std::string inString, std::string delimiter)
    {

        std::string token;
        std::vector<std::string> tokens;
        std::vector<float> joints;
        float tempJ;
        int pos_start = 0, pos_end;
        int delim_len = delimiter.length();

        while ((pos_end = inString.find(delimiter, pos_start)) != std::string::npos)
        {
            token = inString.substr(pos_start, pos_end - pos_start);
            pos_start = pos_end + delim_len;
            tokens.push_back(token);
        }
        tokens.push_back(inString.substr(pos_start));
        if( tokens.size()!= 1)
        {
            for (int i = 0; i < tokens.size(); i++)
            {
                tempJ = std::stof(tokens[i]);
                //std::cout << "string tokens " << i  << " "<< tokens[i] <<std::endl;
                
                joints.push_back(tempJ);
                //std::cout << "joint value " <<i << ": " <<joints[i] <<std::endl;
            }
            return joints;
    };

double distance_in_configuration_space(std::vector<double> q1, std::vector<double> q2){
    double *result = new double[q2.size()];
    for(int k = 0; k < q2.size(); k++) result[k] = q1[k] - q2[k];
    double maximum;
    for(int i = 0; i < q2.size(); i++) result[i] = fabs(result[i]);
    maximum = result[0];
    for(int i = 1; i < q2.size(); i++) maximum = fmax(maximum, b[i]);
    return maximum;    

};

        {
            std::cout << "reached else" <<std::endl;
            joints.push_back(NULL);
            return joints;
        }

        
    }

    int fanucRobot::delta(std::vector<float> j1, std::vector<float> j2)
    {
        std::vector<float> deltaJ;
        float tempV, dm;
        
        deltaJ.clear();

        for(int i = 0 ;i< minAxis; i++)
        {
            tempV = j2[i] - j1[i];
            deltaJ.push_back(tempV);
        }

        dm = *max_element(deltaJ.begin(), deltaJ.end());

        return dm;
    }

} // namespace fanucRobot



import pandas as pd
import numpy as np
import copy

wp = []

j = [0.0,0.0,0.0,0.0,0.0,0.0]

while(j[3]<30.0):
    k = copy.deepcopy(j)
    wp.append(k)
    j[3] = j[3] + 0.024
    print(j[3])
# print(wp)

arr = np.array(wp) 
df = pd.DataFrame(arr)
df.to_csv('trajectory_points.csv', index = False, header=False, sep='\t')

#include "fanucRobot.h"


int main()
{
    std::ofstream meFile;
    std::ifstream myTraj;

    meFile.open("testTrajectory.txt");
    myTraj.open("testTrajectory.txt");
    fanucRobot::fanucRobot robot1("192.168.1.46");
    //robot1.estabalishedComm("192.168.1.170");
    //robot1.sendStartData();
    //robot1.recieveStatusData(1);
    //robot1.printStatus();
    std::vector<float> Joint1,Joint2;
    
    float one = -6.103,two = -25.953, three = -28.558,four = -4.029,five = -58.991,six = 6.041;


    // Joint1.push_back(-13.562);
    // Joint1.push_back(-25.953);
    // Joint1.push_back(-28.558);
    // Joint1.push_back(-4.029);
    // Joint1.push_back(-59.990);
    // Joint1.push_back(6.042);

    Joint2.push_back(one);
    Joint2.push_back(two);
    Joint2.push_back(three);
    Joint2.push_back(four);
    Joint2.push_back(five);
    Joint2.push_back(six);
    std::cout << "After vector joints" << std::endl;
    robot1.rampCSV(meFile,Joint1);
    //std::cout << "Inside main" << Joint1[0] << std::endl;
    robot1.createTrajectoryCSV(meFile,Joint1,Joint2,500,"testTrajectory.txt");
    meFile.close();
    std::cout << "entering read csv file" <<std::endl;
    robot1.readCSV(myTraj);
    //robot1.rampCSV(meFile,Joint1);


    myTraj.close();

    return 0;
}
#incldue <stdint.h>

unsigned int packetType = 1;
unsigned int versionNum = 1, sequenceNum = 1, 

uint8_t lastData = 0;  // 0 for normal conditions, 1 for completed motion trajectory

uint8_t readIOType = 0 , 
        dataStyle = 1, // this is for joint posiyi

short int readIOIndex = 0, readIOMask = 0, 



data = [ 1,1,1,0, ]

int main()
{


    return 0;
}
import socket
import time
import sys 

ip_port = "192.168.1.170"## ip port to communicate to 
port = 60015 ## port number associated with sending the communication


'''
    1. turn on controller
    2. send the start packet
    3. start TP program. 
    ******** HANDSHAKE *************
    * to tes
     PORT number = 60015
     1. START PACKET
        A data pack is sent from the external device to the controller. 
        This packet can be sent anytime after the controoller is powered. 
        ""FORMAT"" -- { }
    2. Robot Status
        A data packet sent from the controller to the extermnal device.
        gives a status update from the robot
            * robot current postion
            * I/O status
            * robot status
            * other hand shaking info
        ""FORMAT"" -- {}
    3. Motion Commnand
        This command should be sent ASAP. need to check the active status flag is = 1.


    last step when streaming motion is done we need to send a 1 as the last byte

'''
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

severAddr = (ip_port,port)
message = "20"

try:
    sock.sendto(bytes.fromhex(message), severAddr)
    time.sleep(0.1)
    data, addr = sock.recvfrom(port)

    a = len(data)
    print ("Byte: ", data.hex()[46], data.hex()[47])
finally:
    print("closing soocket")
    sock.close()

#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <cstring>
#include <stdarg.h>
#include <sstream>
#include <errno.h>
#include <sys/socket.h>
#include <stdint.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <iostream>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <vector>
#include <fstream>

#pragma once

namespace fanucRobot
{

        class fanucRobot
        {
        protected:
                int sockfd, connfd;
                const u_short port = 60015;
                std::string ipAddr;
                char buff[];

        public:
                fanucRobot(std::string ip);
                bool estabalishedComm(std::string sIP);
                void sendStartData();
                std::string recieveStatusData();
                void sendMotionCommands(std::string);
                void recieveStatusData(int);
                void printStatus();
                void initJoints();
                void initPositions();
                void initCurrents();
                void createTrajectoryCSV(std::ofstream &, std::vector<float>, std::vector<float>, float, std::string);
                float avgDelta(std::ifstream &);
                void rampCSV(std::ofstream &, std::vector<float> &);
                void checkJointVel(std::vector<float>, std::vector<float>);
                void readCSV(std::ifstream &);
                std::vector<float> parseString(std::string, std::string);
                int delta(std::vector<float>, std::vector<float>);


        private:
                int startSeqID = 0;
                float curJoint[9];
                float curPos[9];
                float curCurr[9];
                int maxAxis = 9;
                int minAxis = 6;

                // start pack
                struct startPacket
                {
                        unsigned int packetTypeStart = htonl(0L);
                        unsigned int versionNumStart = htonl(1L);
                } startStatus;

                struct robotStatusPacket
                {
                        uint32_t packetTypeRobot;
                        uint32_t versionNumRobot;
                        uint32_t sequenceNumRobot;
                        uint8_t statusRobot,
                            readIOTypeRobot; // 0 for normal conditions, 1 for completed motion trajectory

                        uint16_t readIOIndexRobot, // 0 for normal conditions, 1 for completed motion trajectory
                            readIOValueRobot,
                            readIOMaskRobot; // this is for joint position
                        uint32_t timeStampRobot;
                        uint32_t position[9];
                        uint32_t jointAngle[9];
                        uint32_t current[9];

                } roboStatusPac;

                struct motionCommandPacket
                {
                        // Notion Command Packet

                        unsigned int packetTypeMo;
                        unsigned int versionTypeMo;
                        unsigned int sequenceNumMo = 0;
                        uint8_t lastDataMO,
                            readIOTypeMo;        // 0 for normal conditions, 1 for completed motion trajectory
                        short int readIOIndexMo, // 0 for normal conditions, 1 for completed motion trajectory
                            readIOMaskMo;
                        uint8_t dataStyleMO, // 1 for joint data or 0 for XYZWPR
                            wIOTypeMo;       // 0 if not used
                        short int wIOIndex,
                            wIOMask,
                            wIOValue,
                            emptyValue;
                        float j1DegMo, // [degrees]
                            j2DegMo,
                            j3degMo,
                            j4DegMo,
                            j5DegMo,
                            j6DegMo,
                            j7DegMo,
                            j8DegMo,
                            j9DegMo,
                            xMO,
                            yMo,
                            zMo,
                            wMo,
                            ex1Mo,
                            ex2Mo,
                            ex3Mo;
                } motionCommPac;
        };

} // namespace fanucRobot

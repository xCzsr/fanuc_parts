# GMR_Fanuc
The scripts need to run the Fanuc M-20iD/25. 
